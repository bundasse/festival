<template>
  <NaviMenu />
  <RouterView />
</template>

<script>
import NaviMenu from "./components/Navi.vue"
export default {
  components:{
    NaviMenu
  }
}
</script>

<style>

</style>
