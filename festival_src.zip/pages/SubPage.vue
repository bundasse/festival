<template>
    <div>서브메뉴 페이지</div>
</template>

<script>
export default {
    name: "SubPage" 
}
</script>

<style>

</style>