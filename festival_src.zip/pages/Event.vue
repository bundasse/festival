<template>
    <div>이벤트페이지</div>
</template>

<script>
export default {
    name: "EventPage"
  
}
</script>

<style>

</style>